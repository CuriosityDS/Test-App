﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TEst
{
    public partial class Form3 : Form
    {
        byte[] data;
        string mes;
        int answers, lenght;
        public Form3(byte[] data, int answers, int lenght)
        {
            InitializeComponent();
            this.data = data;
            answer = answers;
            this.lenght = lenght;
        }
        public int answer { get; set; }
        private void Form3_Load(object sender, EventArgs e)
        {
            if (answer==1)
            {
                label3.Text = "Правильный ответ";
            }
            label2.Text = Convert.ToString(answer);
        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form3_MouseDown(object sender, MouseEventArgs e)
        {
            base.Capture = false;
            Message m = Message.Create(base.Handle, 0xa1, new IntPtr(2), IntPtr.Zero);
            this.WndProc(ref m);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
